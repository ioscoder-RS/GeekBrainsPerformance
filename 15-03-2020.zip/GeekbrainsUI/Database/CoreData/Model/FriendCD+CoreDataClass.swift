//
//  FriendCD+CoreDataClass.swift
//  
//
//  Created by raskin-sa on 24/01/2020.
//
//

import Foundation
import CoreData

@objc(FriendCD)
public class FriendCD: NSManagedObject {

}
