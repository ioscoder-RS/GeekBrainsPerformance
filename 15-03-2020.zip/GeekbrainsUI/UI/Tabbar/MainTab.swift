//
//  MainTab.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 20/02/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import UIKit

class MainTab: UITabBarController {
    var vkLogin: VKLogin?
    
//    override init(frame: CGRect) {
//        <#code#>
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
}
