//
//  VKLoginRealm.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 19/02/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//
import RealmSwift

//MARK: текущий = последний логин
class VKLoginRealm: Object {
    @objc dynamic var id = 0
    @objc dynamic var lastName = ""
    @objc dynamic var firstName = ""
    @objc dynamic var userName = ""
    @objc dynamic var avatarPath = ""
    
    override class func primaryKey() -> String? {
        return "id"
    }
    

    func toModel() -> VKLogin{
        return VKLogin(lastName: lastName, firstName: firstName, avatarPath: avatarPath, id: id)
    }
}//class VKUserRealm
