//
//  VKLogin.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 19/02/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation

// MARK: - Последний = текущий логин
struct VKLogin: Codable {
    var lastName:String
    var firstName:String
    var avatarPath:String
    var id:Int
    
    
    enum CodingKeys: String, CodingKey {
        case lastName = "last_name"
        case firstName = "first_name"
        case avatarPath = "photo_50"
        case id
        
    }
}

struct LoginResponse: Codable {
    let response: LoginResponseData
}

// MARK: - Welcome
struct LoginResponseData: Codable {
    let count: Int
    let items: [VKUser]
}

var webVKLogin = [VKLogin]()

