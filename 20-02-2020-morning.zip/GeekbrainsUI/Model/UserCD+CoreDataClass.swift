//
//  UserCD+CoreDataClass.swift
//  
//
//  Created by raskin-sa on 21/01/2020.
//
//

import Foundation
import CoreData

@objc(UserCD)
public class UserCD: NSManagedObject {

}
