//
//  ASDKCell.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 21/03/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation
import AsyncDisplayKit

class ImageNode: ASCellNode {
   private let resource: ImageNodeRepresentable
   private let photoImageNode = ASNetworkImageNode()
  
   init(resource: ImageNodeRepresentable) {
       self.resource = resource
       // Аналогично предыдущей ячейке инициализируем ее через super-инициализатор
       super.init()
      // Донастраиваем внешний вид сабнод
       setupSubnodes()
   }
  
   private func setupSubnodes() {
       photoImageNode.url = resource.url
       photoImageNode.contentMode = .scaleAspectFill
       photoImageNode.shouldRenderProgressImages = true
      
       addSubnode(photoImageNode)
   }
  
   override func layoutSpecThatFits(_ constrainedSize: ASSizeRange) -> ASLayoutSpec {
       let width = constrainedSize.max.width
       photoImageNode.style.preferredSize = CGSize(width: width, height: width*resource.aspectRatio)
       return ASWrapperLayoutSpec(layoutElement: photoImageNode)
   }
    
}


