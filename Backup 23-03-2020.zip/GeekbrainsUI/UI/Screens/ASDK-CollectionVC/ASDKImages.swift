//
//  ASDKCell.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 21/03/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//


import Foundation
import SwiftyJSON

protocol ImageNodeRepresentable {
   var url: URL { get }
   var aspectRatio: CGFloat { get }
}

class Photo: ImageNodeRepresentable {
   let id: Int
   let date: Date
   let width: Int
   let height: Int
   let url: URL
   var aspectRatio: CGFloat { return CGFloat(height)/CGFloat(width) }
  
   init?(json: JSON) {
       // Вытаскиваем массив всех доступных размеров
       guard let sizesArray = json["photo"]["sizes"].array,
       // Используем для отображения только фото хорошего качества
           let xSize = sizesArray.first(where: { $0["type"].stringValue == "x" }),
           let url = URL(string: xSize["url"].stringValue) else { return nil }
      
       self.width = xSize["width"].intValue
       self.height = xSize["height"].intValue
       self.url = url
       let timeInterval = json["date"].doubleValue
       self.date = Date(timeIntervalSince1970: timeInterval)
       print(json["id"].intValue)
       self.id = json["id"].intValue
   }
}

class GIF: ImageNodeRepresentable {
   let id: Int
   let date: Date
   let url: URL
   let width: Int
   let height: Int
   var aspectRatio: CGFloat { return CGFloat(height)/CGFloat(width) } //вычисляемое свойство aspectRatio (соотношение сторон)
  
   init?(json: JSON) {
       guard let url = URL(string: json["url"].stringValue) else { return nil }
       self.id = json["id"].intValue
       self.url = url
       let timeInterval = json["date"].doubleValue
       self.date = Date(timeIntervalSince1970: timeInterval)
       // Для расчета размера гифки используем специальный параметр preview
       self.width = json["preview"]["video"]["width"].intValue
       self.height = json["preview"]["video"]["height"].intValue
   }
}


class NewsItem {
    let id: Int
    let sourceId: Int
    let text: String
    let date: Date
    var source: ASDKNewsSource?
    var photos: [Photo]
    var gif: GIF?
    
    init(json: JSON) {
        self.id = json["id"].intValue
        self.sourceId = json["source_id"].intValue
        self.text = json["text"].stringValue
        
        let timeInterval = json["date"].doubleValue
        self.date = Date(timeIntervalSince1970: timeInterval)
        // Парсим связанные с новостью изображения
        let photosJSON = json["attachments"].arrayValue.filter({ $0["type"].stringValue == "photo" })
        self.photos = photosJSON.compactMap { Photo(json: $0) }
        
        // По возможности вытаскиваем прикрепленные gif-анимации
        let docsJSON = json["attachments"].arrayValue
            .filter({ $0["type"].stringValue == "doc" })
            .map { $0["doc"] }
        
        if !docsJSON.isEmpty {
            let gifsJSON = docsJSON.filter { $0["type"].intValue == 3 }
            if !gifsJSON.isEmpty {
                self.gif = GIF(json: gifsJSON[0])
            }
        }
    }
}//class NewsItem

