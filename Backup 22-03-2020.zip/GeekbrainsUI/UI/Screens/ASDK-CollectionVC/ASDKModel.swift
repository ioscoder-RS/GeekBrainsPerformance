//
//  ASDKModel.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 21/03/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation
import SwiftyJSON
import AsyncDisplayKit

protocol ASDKNewsSource {
   var title: String { get }
   var imageUrl: URL? { get }
}

class ASDKFriend: ASDKNewsSource {
   let id: Int
   let firstName: String
   let lastName: String
   let avatarUrl: URL?
  
   init(json: JSON) {
       self.id = json["id"].intValue
       self.lastName = json["last_name"].stringValue
       self.firstName = json["first_name"].stringValue
       let urlString = json["photo_100"].stringValue
       self.avatarUrl = URL(string: urlString)
   }
  
   // Protocol conformance
   var title: String { return "\(firstName) \(lastName)" }
   var imageUrl: URL? { return avatarUrl }
}

class ASDKGroup: ASDKNewsSource {
   let id: Int
   let name: String
   let avatarUrl: URL?
  
   init(json: JSON) {
       self.id = json["id"].intValue
       self.name = json["name"].stringValue
       let urlString = json["photo_200"].stringValue
       self.avatarUrl = URL(string: urlString)
   }
  
   // Protocol conformance
   var title: String { return name }
   var imageUrl: URL? { return avatarUrl }
}

//Аватарки будут фиксированного размера — 50 точек.
class NewsHeaderNode: ASCellNode {
   //MARK: - Properties
   private let source: ASDKNewsSource
   private let nameNode = ASTextNode()
   private let avatarImageNode = ASNetworkImageNode()
   private let imageHeight: CGFloat = 50
  
   init(source: ASDKNewsSource) {
       self.source = source
      
       super.init()
       backgroundColor = UIColor.white
      
       setupSubnodes()
   }
  
   private func setupSubnodes() {
       nameNode.attributedText = NSAttributedString(string: source.title, attributes: [.font : UIFont.systemFont(ofSize: 20)])
       nameNode.backgroundColor = .clear
       addSubnode(nameNode)
      
       avatarImageNode.url = source.imageUrl
       avatarImageNode.cornerRadius = imageHeight/2
       avatarImageNode.clipsToBounds = true
       avatarImageNode.shouldRenderProgressImages = true
       avatarImageNode.contentMode = .scaleAspectFill
       addSubnode(avatarImageNode)
   }


//Создадим спецификацию лейаута. Для её реализации переопределим метод layoutSpecThatFits(_: ASSizeRange):
 override func layoutSpecThatFits(_ constrainedSize: ASSizeRange) -> ASLayoutSpec {
       // Задаем размер изображения, так как при загрузке из сети он изначально неизвестен
       avatarImageNode.style.preferredSize = CGSize(width: imageHeight, height: imageHeight)
       let insets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
       // Для добавления красивых отступов от границ ячейки вкладываем ячейку в ASInsetLayoutSpec
       let avatarWithInset = ASInsetLayoutSpec(insets: insets, child: avatarImageNode)
      
       // Центрировать текст поможет ASCenterLayoutSpec
       let textCenterSpec = ASCenterLayoutSpec(centeringOptions: .Y, sizingOptions: [], child: nameNode)
      
       // Корневой лейаут будет определять горизонтальный стек
       let horizontalStackSpec = ASStackLayoutSpec()
       horizontalStackSpec.direction = .horizontal
       // Его дочерними элементами будут спецификации, содержащие текст и аватарку
       horizontalStackSpec.children = [avatarWithInset, textCenterSpec]
       return horizontalStackSpec
   }
}//class NewsHeaderNode: ASCellNode
