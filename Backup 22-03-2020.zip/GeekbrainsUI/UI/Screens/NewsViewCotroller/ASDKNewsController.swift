//
//  ASDKcollectionVC.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 20/03/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation
import AsyncDisplayKit

class NewsController: ASViewController<ASDisplayNode>, ASTableDelegate, ASTableDataSource {

 // Создаём дополнительный интерфейс для обращения к корневой ноде
 var tableNode: ASTableNode {
     return node as! ASTableNode
 }
    
    // Добавляем необходимые свойства для дальнейшей работы
     // vkAPi - сетевой сервис для загрузки новостей
     let vkApi = VKAPi()
     // Массив, отображающий новости
     var totalNews = [NewsItem]()
     // Параметр, который позволяет осуществить бесконечный скроллинг
     var nextFrom: String = ""
     // Параметры, необходимые для реализации паттерна pull-to-refresh
     var lastRefreshed: Date?
     var refreshControl: UIRefreshControl = {
         let rC = UIRefreshControl()
         rC.attributedTitle = NSAttributedString(string: "Fetching news...")
         rC.tintColor = .red
         return rC
     }()
    
    init() {
         // Инициализируемся с таблицей в качестве корневого View / Node
         super.init(node: ASTableNode())
         // Привязываем к себе методы делегата и дата-сорса
         self.tableNode.delegate = self
         self.tableNode.dataSource = self
         // По желанию кастомизируем корневую таблицу
         self.tableNode.allowsSelection = false
     }
    
     required init?(coder aDecoder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }
    
    func numberOfSections(in tableNode: ASTableNode) -> Int {
          // Количество секций соответствует количеству загруженных новостей
          return totalNews.count
      }
     
      func tableNode(_ tableNode: ASTableNode, numberOfRowsInSection section: Int) -> Int {
          let newsItem = totalNews[section]
          // В каждой секции -- обязательно один элемент, отображающий заголовок новости
          var rowsCount = 1
          // Если к новости прикреплено фото, добавляем еще одну ячейку
        if !newsItem.photos.isEmpty { rowsCount += 1 }
        // Если к новости прикреплена gif-анимация, добавляем еще одну
        if newsItem.gif != nil { rowsCount += 1 }
        
         return rowsCount
      }// return rowsCount
    
 func tableNode(_ tableNode: ASTableNode, nodeBlockForRowAt indexPath: IndexPath) -> ASCellNodeBlock {
     guard totalNews.count > indexPath.section,
        let source = totalNews[indexPath.section].source else { return { ASCellNode() } }
    
     switch indexPath.row {
     case 0:
         // Первая ячейка -- всегда заголовок. Возвращаем замыкание, создающее NewsHeaderNode
         let cellNodeBlock = { () -> ASCellNode in
             let node = NewsHeaderNode(source: source)
             return node
         }
        
         return cellNodeBlock
     case 1:
         // Вторая ячейка -- либо фото, либо гифка
         if let photo = totalNews[indexPath.section].photos.first {
             let cellNodeBlock = { () -> ASCellNode in
                 let node = ImageNode(resource: photo)
                 return node
             }
            
             return cellNodeBlock
         } else if let gif = totalNews[indexPath.section].gif {
             let cellNodeBlock = { () -> ASCellNode in
                 let node = ImageNode(resource: gif)
                 return node
             }
            
             return cellNodeBlock
         }
         return { ASCellNode() }
        
     case 2:
         // Наличие третьей ячейки на 100 % говорит о наличии гифки в новости
         guard let gif = totalNews[indexPath.section].gif else { return { ASCellNode() } }
         let cellNodeBlock = { () -> ASCellNode in
             let node = ImageNode(resource: gif)
             return node
         }
        
         return cellNodeBlock
    
     default:
         return { ASCellNode() }
     }
 }
}//class NewsController: ASViewController<ASDisplayNode>

//
extension NewsController {
    func shouldBatchFetch(for tableNode: ASTableNode) -> Bool {
        true
    }
    
    func tableNode(_ tableNode: ASTableNode, willBeginBatchFetchWith context: ASBatchContext) {
        vkApi.getNewsList(token: Session.shared.token, userId: Session.shared.userId, nextFrom: self.nextFrom, startTime: nil, version: Session.shared.version) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case let .success(news):
                self.nextFrom = news.nextFrom ?? ""
                self.insertNews(news)
                context.completeBatchFetching(true)
            case let .failure(error):
                self.showAlert(error: error)
                context.completeBatchFetching(false)
            }
        }
    }
    
    private func insertNews(_ news: [NewsItem]) {
        let indexSet = IndexSet(integersIn: totalNews.count ..< totalNews.count + news.count)
        totalNews.append(contentsOf: news)
        tableNode.insertSections(indexSet, with: .automatic)
    }
}
